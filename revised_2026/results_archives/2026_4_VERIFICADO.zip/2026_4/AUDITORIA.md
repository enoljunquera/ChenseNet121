# Auditoría de las predicciones LD50

Resultado: la selección de archivos y las métricas son correctas. Esta copia
también resuelve una inconsistencia en una columna auxiliar del exportador.

## Comprobaciones

- Nueve grupos de resultados, cada uno con los diez tests: 90 pares modelo/test.
- 180 CSV individuales: uno por fila y otro por estructura para cada par.
- 18 CSV agregados: coinciden con la unión de sus diez archivos individuales.
- Cohorte observada en el conjunto de tests: 249 registros y 199 estructuras.
- Todos los modelos usan los mismos registros, estructuras y targets en cada test.
- Tests 1, 4 y 5: 54 archivos individuales proceden de `2026_2`.
- Tests 2, 3, 6, 7, 8, 9 y 10: 126 archivos proceden de `2026_3_correccion_outlier`.
- ChenseNet utiliza `BEST_CHECKPOINT`; la variante ponderada está separada.
- Propamocarb aparece exclusivamente en los tests 1, 4 y 5 y tiene `LD50_real = 5250`.
- Los targets por estructura, las medias de predicciones y el número de registros concuerdan.
- Los errores individuales y las métricas fueron recalculados de forma independiente.
- Las 360 celdas MAE/MSE coinciden con `PARTITION_METRICS_REBUILT(2).csv`.
- Los checksums de los CSV individuales coinciden con `procedencia.csv`.

## Única inconsistencia encontrada y resuelta

La columna principal `LD50_real` y las métricas ya estaban corregidas. Sin embargo,
la columna auxiliar `LD50` conservaba 43500 para propamocarb en los CSV por fila
de ChenseNet121, ChInceptionV3 y ChenseNet121_structure_weighted, tests 1, 4 y 5.
Sus tres archivos agregados también heredaban ese valor.

Esta copia sustituye exclusivamente esos 18 valores auxiliares por 5250:
9 valores en CSV individuales y 9 en sus agregados. Registra 9 correcciones
adicionales de archivos fuente y actualiza los checksums y la documentación.
Las predicciones, `LD50_real`, los errores y las métricas no cambian.
El archivo ZIP original no se ha modificado.

## Métricas de control

Promedios de los diez tests, evaluación por estructura. MSE expresado en millones.

| Modelo | MSE medio / 10^6 | MAE medio (mg/kg) |
|---|---:|---:|
| ChenseNet121 | 15.782544 | 2420.504059 |
| ChInceptionV3 | 15.823013 | 2425.219856 |
| LinearSVR_affinity | 16.624987 | 2378.601094 |
| RandomForest_affinity | 17.245073 | 2390.246957 |
| Ridge_affinity | 18.054509 | 2461.088695 |
| LinearSVR_NoDock | 16.576631 | 2370.288562 |
| RandomForest_NoDock | 17.837561 | 2468.342692 |
| Ridge_NoDock | 18.198596 | 2471.564472 |
| ChenseNet121_structure_weighted | 15.611601 | 2416.077349 |

## Alcance de la verificación

Los CSV fuente originales, los datasets de entrenamiento y los checkpoints no
están dentro de este ZIP. La procedencia se ha comprobado contra los registros
del paquete y las métricas corregidas externas; esta revisión no vuelve a entrenar
los modelos ni verifica los pesos de los checkpoints.

Los diez tests son particiones de evaluación repetidas que se solapan. Los
agregados conservan la columna `Test_2026_4`: no representan 10 datasets independientes.
